#include "FileSystem.h"


int main(){
	
	HFS_install();
	HFS_init();
	CMD_init();
	console();


}

